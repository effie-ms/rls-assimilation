# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rls_assimilation']

package_data = \
{'': ['*']}

install_requires = \
['numpy']

setup_kwargs = {
    'name': 'rls-assimilation',
    'version': '0.1.0',
    'description': 'RLS-based data assimilation',
    'long_description': None,
    'author': 'Lizaveta Miasayedava',
    'author_email': 'lizaveta.miasayedava@taltech.ee',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
}


setup(**setup_kwargs)
